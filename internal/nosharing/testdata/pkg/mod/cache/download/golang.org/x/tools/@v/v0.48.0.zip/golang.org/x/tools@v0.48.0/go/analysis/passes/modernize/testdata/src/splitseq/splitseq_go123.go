package splitseq
